float **rndWeightGraph(int size);
void printGraph(float **adjmat,int size);
